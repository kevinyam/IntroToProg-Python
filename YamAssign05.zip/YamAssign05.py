#-------------------------------------------------#
# Title: To Do List Assignment 5
# Dev:   Kevin Yam
# Date:  November 12, 2018
# ChangeLog: (Who, When, What)
#   Kevin Yam, 11/12/2018, Created program
#-------------------------------------------------#

#-- Data --#
# declare variables and constants
objFileName = "ToDo.txt" # The file name
objFile = "" # An object that represents a file
dicRow = {} # A row of data separated into elements of a dictionary {Task,Priority}
lstTable = [] # lstTable = A dictionary that acts as a 'table' of rows
inputTask = "" # User input task
inputPriority = "" # User input priority
index = None # An index value
#-------------------------------

#-- Processing --#
# Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"
objFile = open(objFileName,"r")
for fileLine in objFile:
    fileLine = fileLine.rstrip() # Removes the new line character
    fileLine = fileLine.split(",") # Splits the string with the , as the separator
    dicRow = {"Task":fileLine[0], "Priority":fileLine[1]}
    lstTable.append(dicRow)
objFile.close()
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        #Prints every value in the list of task
        for row in lstTable:
            print(row)
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        # Ask the user for the task and its priority
        inputTask = input("Enter a task:")
        inputPriority = input("Enter the Priority:")
        # Sets the input as a dictionary and adds it into the list
        dicRow = {"Task":inputTask, "Priority": inputPriority.lower()}
        lstTable.append(dicRow)
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        # Asks the user to input the task that they wish to remove
        inputTask = input("Enter task you wish to remove:")
        # Tries to remove the task and returns a message if it does not exist
        try:
            for i, lstRow in enumerate(lstTable): # For every dictionary in the list and its index
                if lstRow["Task"].lower() == inputTask.lower(): # Checks for the task
                    index = i
            lstTable.pop(index) #Tries to remove the task
            index = None #Return the index value to None
        except:
            print("Task entered does not exist.")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        objFile = open(objFileName,"w")
        for lstRow in lstTable: # For every dictionary value in the table
            # Writes the task and priority separated by a comma
            objFile.write("%s,%s\n" %(lstRow["Task"], lstRow["Priority"]))
        objFile.close()
        print("Save Complete")
        continue
    elif (strChoice == '5'):
        break #and Exit the program
#-------------------------------