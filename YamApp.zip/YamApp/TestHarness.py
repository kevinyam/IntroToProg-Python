if __name__ == "__main__":
    import PersonMod, CustomerMod, DataProcessor
else:
    raise Exception("This file was not created to be imported")

print("Test PersonMod.Person class")

person1 = PersonMod.Person("John", "Smith")
print(person1.ToString())
person1.FirstName = "Jane"
person1.LastName = "Doe"
print(person1)


print("\nTest CustomerMod.Customer class")

customer1 = CustomerMod.Customer("John", "Smith","1234")
print(customer1.ToString())
customer1.FirstName = "Johnathan"
print(customer1)
customer2 = CustomerMod.Customer("Jane", "Doe", "4321")
print(customer2.ToString())
print(customer1.__class__)

print("\nTest CustomerMod.CustomerList class")
CustomerMod.CustomerList.AddCustomer(customer1)
CustomerMod.CustomerList.AddCustomer(customer2)
print(CustomerMod.CustomerList.ToString())

print("\nTest the DataProcessor.File class")
objDP = DataProcessor.File()
objDP.FileName = "Test.txt"
objDP.TextData = "This is a test"
strMessage = objDP.SaveData()
print(strMessage)
print("Data in Test.txt:")
print(objDP.GetData())
