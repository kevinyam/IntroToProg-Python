# -------------------------------------------------#
# Title: EmployeeApp
# Dev:   RRoot
# Date:  12/12/2020
# Desc: This application manages employee data
# ChangeLog: (Who, When, What)
#
# -------------------------------------------------#
if __name__ == "__main__":
    import DataProcessor, CustomerMod
else:
    raise Exception("This file was not created to be imported")

# -- Data --#
# declare variables and constants
objC = None  # a customer object
strFirstName = ""  # a customer's first name
strLastName = ""  # a customer's last name
strPhoneNumber = "" # a customer's phone number
intID = None # a customer's ID
strInput = ""  # temporary user input


# -- Processing --#
# perform tasks
def ProcessNewCustomerData(FirstName, LastName, PhoneNumber):
    try:
        # Create Employee object
        objC = CustomerMod.Customer(FirstName,LastName,PhoneNumber)
        CustomerMod.CustomerList.AddCustomer(objC)
    except Exception as e:
        print(e)

def RemoveExistingCustomerData(ID):
    try:
        CustomerMod.CustomerList.RemoveCustomer(ID)
    except Exception as e:
        print(e)

def SaveDataToFile():
    try:
        objF = DataProcessor.File()
        objF.FileName = "CustomerData.txt"
        objF.TextData = CustomerMod.CustomerList.ToString()
        print("Reached here")
        objF.SaveData()
    except Exception as e:
        print(e)


# -- Presentation (I/O) --#
# __main__

# get user input
strUserInput = ""
while (True):
    strUserInput = input("Would you like to add Customer data? (y/n)")
    if (strUserInput.lower() == "y"):
        # Get Customer First Name from the User
        strFirstName = str(input("Enter the Customer's First Name: "))
        # Get Customer Last Name from the User
        strLastName = str(input("Enter the Customer's Last Name: "))
        # Get Customer Phone Number from User
        strPhoneNumber = str(input("Enter the Customer's Phone Number "))
        # Process input
        ProcessNewCustomerData(strFirstName, strLastName, strPhoneNumber)
    elif (strUserInput.lower() == "n"):
        break
    else:
        print("Input not valid, please enter y/n")

    # send program output
print("The Current Data is: ")
print("------------------------")
print(CustomerMod.CustomerList.ToString())

while (True):
    strUserInput = input("Would you like to remove any Customer data? (y/n)")
    if (strUserInput.lower() == "y"):
        # Get Customer ID they wish to remove
        strID = int(input("Enter the ID of the Customer you wish to remove: "))
        # Process input
        RemoveExistingCustomerData(strID)
    elif (strUserInput == "n"):
        break
    else:
        print("Input not valid, please enter y/n")

    # send program output
print("The Current Data is: ")
print("------------------------")
print(CustomerMod.CustomerList.ToString())

# get user input
strInput = input("Would you like to save this data to the dat file?(y/n)")
if (strInput == "y"):
    SaveDataToFile()
    # send program output
    print("data saved in file")
else:
    print("data was not saved")

print("This application has ended. Thank you!")
