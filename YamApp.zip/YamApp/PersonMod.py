# ------------PersonMod.py Module ---------------#
# Desc:  Module that holds the Person class
# Dev:   Kevin Yam
# Date:  12/03/2018
# ChangeLog: Created Module for classes related to person
# ---------------------------------------------#
if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself")

# --- Make the class ---
class Person(object):
    """ Base Class for Personal data """
    # -------------------------------------#
    # Desc:  Holds Personal data
    # Dev:   Kevin Yam
    # Date:  12/03/2018
    # ChangeLog: Created Class to hold personal data
    # -------------------------------------#

    # --Fields--

    # --Constructor--
    def __init__(self, FirstName = "", LastName = ""):
        # Attributes
        self.__FirstName = FirstName  # Private Attribute
        self.__LastName = LastName

    # --Properties--
    # FirstName
    @property  # getter(accessor)
    def FirstName(self):
        return self.__FirstName

    @FirstName.setter  # (mutator)
    def FirstName(self, Value):
        self.__FirstName = Value

    @property
    def LastName(self):
        return self.__LastName

    @LastName.setter
    def LastName(self, Value):
        self.__LastName = Value

    # --Methods--
    def ToString(self):
        """Explictly returns field data"""
        return self.FirstName + "," + self.LastName

    def __str__(self):
        """Implictly returns field data"""
        return self.ToString()

    # --End of class Person--
