# ------------CustomerMod.py Module ---------------#
# Desc:  Module that holds the Customer class
# Dev:   Kevin Yam
# Date:  12/03/2018
# ChangeLog: Created Module for classes related to customer that inherits person
# ---------------------------------------------#
import PersonMod

if __name__ == "__main__":
    raise Exception("This file is not meant to run by itself")

# --- Make the class ---
class Customer(PersonMod.Person):
    """ Base Class for Customer data """
    # -------------------------------------#
    # Desc:  Holds Customer data
    # Dev:   Kevin Yam
    # Date:  12/03/2018
    # ChangeLog: Created Class to hold customer data inheriting person
    # -------------------------------------#

    # --Fields--
    __Counter = 0 # Lets the program set the ID for the customer instead

    # --Constructor--
    def __init__(self, FirstName = "", LastName = "", Phone = "" ):
        # Attributes
        super().__init__(FirstName,LastName)
        self.__ID = self.__Counter  # Private Attribute
        self.__Phone = Phone
        Customer.__SetObjectCount()

    # --Properties--
    # Phone
    @property  # getter(accessor)
    def Phone(self):
        return self.__Phone

    @Phone.setter  # (mutator)
    def Phone(self, Value):
        self.__Phone = Value

    # ID
    @property
    def ID(self):
        return self.__ID

    @ID.setter
    def ID(self, Value):
        self.__ID = Value

    # --Methods--
    def ToString(self):
        """Explictly returns field data"""
        return "ID:" + str(self.ID) + ",Name:" + super().ToString() + ",Phone:" + self.Phone

    def __str__(self):
        """Implictly returns field data"""
        return self.ToString()

    # Increase the counter for the next Customer
    @staticmethod
    def __SetObjectCount(): # This is a private and static method
        Customer.__Counter += 1

    # --End of class Customer--


class CustomerList(object):
    """ Static class for holding a list of Customer data """
    # -------------------------------------#
    # Desc:  Manages a list of Employee data
    # Dev:   RRoot
    # Date:  12/12/2020
    # ChangeLog:(When,Who,What)
    # -------------------------------------#

    # --Fields--
    __lstCustomers = []  # a list with Employee objects

    # --Constructor--
    # @staticmethod in python constructors cannot be static
    # def __init__():
    # Attributes

    # --Properties--
    # None

    # --Methods--
    @staticmethod
    def AddCustomer(Customer):
        # print(Customer.__class__)  # for testing
        if (str(Customer.__class__) == "<class 'CustomerMod.Customer'>"):
            CustomerList.__lstCustomers.append(Customer)
            # print(CustomerList.__lstCustomer)#for testing
        else:
            raise Exception("Only Customer objects can be added to this list")

    @staticmethod
    def RemoveCustomer(ID):
        CustomerList.__lstCustomers[ID].FirstName = "Removed"
        CustomerList.__lstCustomers[ID].LastName = "Removed"
        CustomerList.__lstCustomers[ID].Phone = "Removed"
        return "Customer" + str(ID) + "has been removed.\n"

    @staticmethod
    def ToString():  # This overrides the original method (it's polymorphic)
        """Explictly returns field data"""
        strData = "ID,First Name,Last Name,Phone:\n"
        for item in CustomerList.__lstCustomers:
            strData += str(item.ID) + "," + item.FirstName + "," + item.LastName + "," + item.Phone + "\n"
        return strData

    @staticmethod
    def __str__():  # This overrides the original method as well
        """Implictly returns field data"""
        strData = CustomerList.ToString
        return strData

    # --End of Class --
