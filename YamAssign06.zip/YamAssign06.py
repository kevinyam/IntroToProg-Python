#-------------------------------------------------#
# Title: To Do List Assignment 6
# Dev:   Kevin Yam
# Date:  November 12, 2018
# ChangeLog: (Who, When, What)
#   Kevin Yam, 11/12/2018, Created program for a To Do List using Class and Functions
#-------------------------------------------------#

# This program will interact with a to do list using functions.
# The class will encapsulate all the function beside the menu
# The main body of the script will run create the initial list and run the menu

# This will be the class object that will encapsulate all the function besides the menu
# The menu will be separate since it is more of an user interface
class ToDoListFunctions(object):

    @staticmethod
    def make_to_do_list(fileName):
        """This function reads a file and returns a to do list"""
        objFile = open(fileName,"r")
        temp_list = [] # temp list that will be returned
        temp_dic = {} # temp dictionary
        for fileLine in objFile: # this reads every line in the file
            # This will separate the line into the dictionary and add it to the list
            fileLine = fileLine.split(",")
            temp_dic = {"Task": fileLine[0].rstrip(), "Priority": fileLine[1].rstrip()}
            temp_list.append(temp_dic)
        objFile.close()
        return temp_list # Returns the list

    @staticmethod
    def print_list(temp_list):
        '''This function prints the to do list'''
        #Prints every value in the list of task
        for row in temp_list:
            print("Task: %s, Priority %s" %(row["Task"], row["Priority"]))
        return None

    @staticmethod
    def add_task(temp_list):
        '''This function adds a task and priority and returns the new list'''
        # Ask the user for the task and its priority
        temp_task = input("Enter a task:")
        temp_prior = input("Enter the Priority:")
        # Sets the input as a dictionary and adds it into the list
        temp_dic = {"Task": temp_task.rstrip(), "Priority": (temp_prior.lower()).rstrip()}
        temp_list.append(temp_dic)
        return temp_list

    @staticmethod
    def remove_task(temp_list):
        '''This function removes a task from the list'''
        # Asks the user to input the task that they wish to remove
        inputTask = input("Enter task you wish to remove:")
        index = None
        # Tries to remove the task and returns a message if it does not exist
        try:
            for i, lstRow in enumerate(temp_list):  # For every dictionary in the list and its index
                if lstRow["Task"].lower() == inputTask.lower():  # Checks for the task
                    index = i
            temp_list.pop(index)  # Tries to remove the task
        except:
            print("Task entered does not exist.")
        return temp_list

    @staticmethod
    def save_list(temp_list, temp_file):
        '''This function saves the to do list into a file'''
        objFile = open(temp_file, "w")
        for lstRow in temp_list:  # For every dictionary value in the table
            # Writes the task and priority separated by a comma
            objFile.write("%s,%s\n" % (lstRow["Task"], lstRow["Priority"]))
        objFile.close()
        print("Save Complete")
        return None

# Defines the function for the user interface menu
def to_do_menu(temp_list, temp_file):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line
    # Show the current items in the table
    if (strChoice.strip() == '1'):
        ToDoListFunctions.print_list(temp_list)
        return False
    # Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        temp_list = ToDoListFunctions.add_task(temp_list)
        return False
    # Remove a new item to the list/Table
    elif(strChoice == '3'):
        temp_list = ToDoListFunctions.remove_task(temp_list)
        return False
    # Save tasks into the file entered
    elif(strChoice == '4'):
        ToDoListFunctions.save_list(temp_list, temp_file)
        return False
    elif (strChoice == '5'):
        print("Good Bye")
        return True #and Exit the program
    #-------------------------------

# -- Data --#
# declare variables and constants
objFileName = "ToDo.txt"  # The file name
lstTable = []  # The list of task
exit = None
# Creates the initial list by passing the file name
lstTable= ToDoListFunctions.make_to_do_list(objFileName)

# Loops the menu until the user chooses to exit
while(True):
    exit = to_do_menu(lstTable,objFileName)
    if exit == True:
        break
# -------------------------------
