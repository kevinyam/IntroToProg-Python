# -------------------------------------------------#
# Title: Pickling Assignment 7
# Dev:   Kevin Yam
# Date:  November 19, 2018
# ChangeLog: (Who, When, What)
#   Kevin Yam, 11/12/2018, Created program to showcase pickle usage in python
# -------------------------------------------------#
import pickle
# imports pickle module

# Data

# Two dictionary data with strings and integer to dump
pie1 = {"Pie":"Apple", "Cost":5}
pie2 = {"Pie":"Peach", "Cost":7}
loop = None

# This try to will open the file and dump the dictionary data into the file
try:
    # Opens the file in write binary mode if it exist
    pieFile = open("PieList.dat", "wb")
    # Writes the data for pie1 & pie2
    pickle.dump(pie1, pieFile)
    pickle.dump(pie2, pieFile)
    pieFile.close()
except Exception as e:
    # Prints out the exception thrown
    print(e)

# Tries to open the file for reading
try:
    pieFile = open("PieList.dat", "rb")
    # If the file could be opened, set loop to True
    loop = True
except:
    # If the file fails to open, set loop False
    loop = False
    print("File could not be opened")

# If the file was opened, load all the data
while loop:
    try:
        # Loads and prints out the object inside the file
        print(pickle.load(pieFile))
    except EOFError:
        # Once there is no more objects to load, Stop
        print("All pickled objects have been loaded")
        pieFile.close()
        break;