# -------------------------------------------------#
# Title: Exception Handling Assignment 7
# Dev:   Kevin Yam
# Date:  November 19, 2018
# ChangeLog: (Who, When, What)
#   Kevin Yam, 11/12/2018, Created program to showcase exception handing in python
# -------------------------------------------------#

# This program will show examples of exception handling
myNumber = 5

# The script will ask the user for an integer from 1 to 10
# If the user entered anything besides 1 to 10, it will create an error
try:
    # If the user enters an integer it will work otherwise it will go to the exception
    guess = int(input("Guess an integer from 1 to 10: "))
    # If the integer entered is within 1 to 10 continue
    if guess in range(1,11):
        pass
    else:
        # If the integer is not within 1 to 10 it will force an exception
        raise Exception;
    if guess == myNumber:
        print("You guessed correctly")
    else:
        print("Guess again")
# This exception will occur when anything besides an integer is entered
except ValueError as e:
    # Prints out the error as well as a custom message
    print("Error: " + str(e))
    print("You did not enter an integer")
# Using this exception when the integer is not within 1 to 10
except Exception:
    print("Number is not within 1 to 10")
# Prints out final message regardless of what was entered
finally:
    print("Good Bye")